import { ImageResponse } from "next/og";
import { getLatestWeather } from "@/lib/latest-weather";

export const dynamic = "force-dynamic";

export async function GET() {
  const latest = await getLatestWeather();
  const temperature = latest ? `${Math.round(latest.temperature)}°` : "--°";
  const heatIndex = latest && Math.round(latest.heatIndex) !== Math.round(latest.temperature)
    ? `HEAT INDEX ${Math.round(latest.heatIndex)}°F`
    : null;
  const location = latest?.location ?? "LOCAL WEATHER";
  const detail = latest
    ? `DEW POINT ${Math.round(latest.dewpoint)}°F  ·  LATEST PHONE UPDATE`
    : "OPEN THE SITE FOR CURRENT CONDITIONS";

  return new ImageResponse(
    <div style={{
      width: "100%", height: "100%", display: "flex", flexDirection: "column",
      justifyContent: "space-between", background: "#ffffff", color: "#000000",
      padding: "58px 70px", fontFamily: "Arial, Helvetica, sans-serif",
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ fontSize: 25, fontWeight: 700, letterSpacing: 5 }}>LOCAL CONDITIONS</div>
        <div style={{ border: "4px solid #000", borderRadius: 999, padding: "12px 22px", fontSize: 20, fontWeight: 700 }}>
          {latest ? "CURRENT" : "WAITING"}
        </div>
      </div>
      <div style={{ display: "flex", flexDirection: "column" }}>
        <div style={{ fontSize: 300, fontWeight: 900, lineHeight: 0.82, letterSpacing: -22 }}>{temperature}</div>
        {heatIndex ? <div style={{ marginTop: 32, color: "#c00000", fontSize: 42, fontWeight: 700, letterSpacing: 3 }}>{heatIndex}</div> : null}
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", fontFamily: "Courier New, monospace" }}>
        <div style={{ fontSize: 27, fontWeight: 700, textTransform: "uppercase" }}>{location}</div>
        <div style={{ fontSize: 20, color: "#444", letterSpacing: 1 }}>{detail}</div>
      </div>
    </div>,
    {
      width: 1200,
      height: 630,
      headers: { "Cache-Control": "public, max-age=300, stale-while-revalidate=60" },
    },
  );
}
