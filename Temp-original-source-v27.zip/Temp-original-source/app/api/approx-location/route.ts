export const dynamic = "force-dynamic";

type CloudflareRequest = Request & {
  cf?: {
    latitude?: string | number;
    longitude?: string | number;
    city?: string;
    regionCode?: string;
  };
};

export async function GET(request: Request) {
  const cf = (request as CloudflareRequest).cf;
  const latitude = Number(cf?.latitude);
  const longitude = Number(cf?.longitude);

  if (!Number.isFinite(latitude) || latitude < -90 || latitude > 90
    || !Number.isFinite(longitude) || longitude < -180 || longitude > 180) {
    return Response.json({ error: "Approximate location unavailable." }, {
      status: 404,
      headers: { "Cache-Control": "no-store" },
    });
  }

  const label = [cf?.city, cf?.regionCode].filter(Boolean).join(", ");
  return Response.json({ latitude, longitude, label: label || null, approximate: true }, {
    headers: { "Cache-Control": "private, no-store" },
  });
}
