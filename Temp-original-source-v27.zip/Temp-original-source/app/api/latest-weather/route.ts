import { env } from "cloudflare:workers";
import { LATEST_WEATHER_KEY, type LatestWeather } from "@/lib/latest-weather";

export const dynamic = "force-dynamic";

type ReadingInput = Omit<LatestWeather, "updatedAt">;

function validNumber(value: unknown, minimum: number, maximum: number): value is number {
  return typeof value === "number" && Number.isFinite(value) && value >= minimum && value <= maximum;
}

function parseReading(value: unknown): ReadingInput | null {
  if (!value || typeof value !== "object") return null;
  const reading = value as Partial<ReadingInput>;
  const location = typeof reading.location === "string" ? reading.location.trim() : "";
  if (!validNumber(reading.temperature, -100, 150)
    || !validNumber(reading.dewpoint, -150, 150)
    || !validNumber(reading.heatIndex, -100, 250)
    || !validNumber(reading.fetchedAt, 0, Date.now() + 5 * 60 * 1000)
    || !location
    || location.length > 80) return null;

  return {
    temperature: reading.temperature,
    dewpoint: reading.dewpoint,
    heatIndex: reading.heatIndex,
    fetchedAt: reading.fetchedAt,
    location,
  };
}

export async function POST(request: Request) {
  const contentLength = Number(request.headers.get("content-length") || 0);
  if (!request.headers.get("content-type")?.startsWith("application/json") || contentLength > 4096) {
    return Response.json({ error: "Invalid request." }, { status: 415 });
  }

  let input: ReadingInput | null = null;
  try {
    input = parseReading(await request.json());
  } catch {
    input = null;
  }
  if (!input) return Response.json({ error: "Invalid weather reading." }, { status: 400 });
  if (!env.BUCKET) return Response.json({ error: "Weather image storage is unavailable." }, { status: 503 });

  const latest: LatestWeather = { ...input, updatedAt: Date.now() };
  await env.BUCKET.put(LATEST_WEATHER_KEY, JSON.stringify(latest), {
    httpMetadata: { contentType: "application/json" },
  });
  return Response.json({ updated: true }, { headers: { "Cache-Control": "no-store" } });
}
