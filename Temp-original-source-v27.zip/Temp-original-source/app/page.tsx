import Script from "next/script";

export default function Home() {
  return (
    <>
      <div className="shell">
        <header>
          <div className="header-copy">
            <p className="eyebrow">Local conditions</p>
            <p className="last-updated"><time id="lastUpdated">Waiting for weather…</time></p>
          </div>
          <div id="status" className="status loading" role="status" aria-live="polite">Starting</div>
        </header>

        <main>
          <a id="weatherAlert" className="weather-alert" href="https://www.weather.gov/alerts" target="_blank" rel="noopener noreferrer" role="alert" hidden>
            <strong id="alertTitle">Weather warning</strong>
            <span id="alertTime" />
          </a>
          <section id="reading" className="reading thermal-neutral" aria-label="Current weather" aria-busy="true">
            <p id="temperature" className="temperature" data-width="standard" aria-label="Temperature loading">--<span className="unit">°F</span></p>
            <p id="heatIndex" className="heat-index" hidden />
            <p className="dewpoint">
              <span className="weather-metric">Dew point <strong id="dewpoint">--°F</strong></span>
              <span className="weather-divider" aria-hidden="true">·</span>
              <span className="weather-metric">Humidity <strong id="humidity">--%</strong></span>
            </p>
          </section>

          <section id="errorCard" className="error-card" hidden aria-live="assertive">
            <p className="error-kicker">Update failed</p>
            <h1 id="errorTitle">Weather unavailable</h1>
            <p id="errorMessage">The weather could not be loaded.</p>
            <p id="errorDetail" className="error-detail" />
            <div className="error-actions">
              <button id="errorRetry" className="refresh inverted" type="button">Retry now</button>
              <a id="openBrowser" className="refresh" href="./" target="_blank" rel="noopener noreferrer" hidden>Open in browser</a>
            </div>
          </section>

          <noscript>
            <section className="error-card noscript-card">
              <p className="error-kicker">JavaScript blocked</p>
              <h1>Weather cannot start</h1>
              <p>Enable JavaScript for this site, then reload the page.</p>
              <a className="refresh inverted" href="./">Reload page</a>
            </section>
          </noscript>
        </main>

        <footer>
          <p id="meta" className="meta">Your location is used only to request local weather from the National Weather Service.</p>
          <button id="refresh" className="refresh" type="button">Use my location</button>
        </footer>
      </div>
      <Script src="/app.js?v=12" strategy="afterInteractive" />
    </>
  );
}
