import type { Metadata, Viewport } from "next";
import { getLatestWeather } from "@/lib/latest-weather";
import "./globals.css";

const SITE_ORIGIN = "https://local-weather-poster.c6gkfnyv9j.chatgpt.site";

export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  const latest = await getLatestWeather();
  const version = latest?.updatedAt ?? "waiting";
  const imageUrl = `${SITE_ORIGIN}/og.png?v=${encodeURIComponent(version)}`;
  const description = latest
    ? `${Math.round(latest.temperature)}°F in ${latest.location}, from the latest phone weather update.`
    : "Local temperature, heat index, and dew point from the National Weather Service.";

  return {
    metadataBase: new URL(SITE_ORIGIN),
    title: "Temp°",
    applicationName: "Temp°",
    manifest: "/manifest.webmanifest?v=temp-name-2",
    appleWebApp: {
      capable: true,
      title: "Temp°",
      statusBarStyle: "default",
    },
    description,
    openGraph: {
      type: "website",
      url: SITE_ORIGIN,
      title: "Temp°",
      description,
      images: [{ url: imageUrl, width: 1200, height: 630, alt: description }],
    },
    twitter: {
      card: "summary_large_image",
      title: "Temp°",
      description,
      images: [imageUrl],
    },
    icons: {
      icon: [
        { url: "/icons/weather-32.png", sizes: "32x32", type: "image/png" },
        { url: "/icons/weather-192.png", sizes: "192x192", type: "image/png" },
      ],
      shortcut: "/icons/weather-32.png",
      apple: [{ url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
    },
  };
}

export const viewport: Viewport = { themeColor: "#ffffff" };

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
