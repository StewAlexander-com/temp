import assert from 'node:assert/strict';
import test from 'node:test';
import { evolveCandidates } from '../lib/signal-life.mjs';

const environments = ['normal', 'stale', 'degraded', 'hot', 'cold', 'severe'];
const quiet = { signal: 0, noise: 0 };

const candidates = [
  {
    name: 'truthful-freshness',
    environments: {
      normal: { signal: 3, noise: 0 }, stale: { signal: 8, noise: 0 },
      degraded: { signal: 7, noise: 0 }, hot: { signal: 2, noise: 0 },
      cold: { signal: 2, noise: 0 }, severe: { signal: 4, noise: 0 },
    },
  },
  {
    name: 'isolated-warnings',
    environments: { normal: quiet, stale: quiet, degraded: quiet, hot: quiet, cold: quiet, severe: { signal: 10, noise: 1 } },
  },
  {
    name: 'conditional-wind-chill',
    environments: { normal: quiet, stale: quiet, degraded: quiet, hot: quiet, cold: { signal: 7, noise: 1 }, severe: quiet },
  },
  {
    name: 'condition-decoration',
    environments: { normal: { signal: 2, noise: 3 } },
  },
  {
    name: 'forecast-dashboard',
    environments: { normal: { signal: 4, noise: 5 } },
  },
  {
    name: 'radar',
    environments: { normal: { signal: 6, noise: 4, criticalRegression: true } },
  },
  {
    name: 'always-visible-extra-metrics',
    environments: { normal: { signal: 3, noise: 6 } },
  },
  {
    name: 'weather-colored-background',
    environments: { normal: { signal: 1, noise: 4 } },
  },
  {
    name: 'stale-first-offline-mode',
    environments: { normal: quiet, stale: { signal: 4, noise: 2, criticalRegression: true } },
  },
];

test('only candidates with positive signal, dormant quiet, and no critical regression survive', () => {
  assert.deepEqual(
    evolveCandidates(candidates, environments).map(candidate => candidate.name),
    ['truthful-freshness', 'isolated-warnings', 'conditional-wind-chill'],
  );
});

