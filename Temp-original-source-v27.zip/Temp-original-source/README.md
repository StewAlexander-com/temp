# Local Weather

A location-aware temperature poster using phone geolocation and National Weather Service data. The latest successful phone reading also updates a dynamic Open Graph and X preview image without storing coordinates.
