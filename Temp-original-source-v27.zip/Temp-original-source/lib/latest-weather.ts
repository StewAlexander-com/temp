import { env } from "cloudflare:workers";

export const LATEST_WEATHER_KEY = "latest-weather.json";

export type LatestWeather = {
  temperature: number;
  dewpoint: number;
  heatIndex: number;
  location: string;
  fetchedAt: number;
  updatedAt: number;
};

export async function getLatestWeather(): Promise<LatestWeather | null> {
  try {
    const object = await env.BUCKET?.get(LATEST_WEATHER_KEY);
    if (!object) return null;
    const value = await object.json<LatestWeather>();
    return isLatestWeather(value) ? value : null;
  } catch {
    return null;
  }
}

export function isLatestWeather(value: unknown): value is LatestWeather {
  if (!value || typeof value !== "object") return false;
  const reading = value as Partial<LatestWeather>;
  return Number.isFinite(reading.temperature)
    && Number.isFinite(reading.dewpoint)
    && Number.isFinite(reading.heatIndex)
    && Number.isFinite(reading.fetchedAt)
    && Number.isFinite(reading.updatedAt)
    && typeof reading.location === "string"
    && reading.location.length > 0
    && reading.location.length <= 80;
}
